const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.static('public'));

let players = {};

io.on('connection', (socket) => {
    console.log('New player connected: ' + socket.id);

    players[socket.id] = { x: 0, y: 1.6, z: -3 };

    socket.on('disconnect', () => {
        console.log('Player disconnected: ' + socket.id);
        delete players[socket.id];
    });

    socket.on('updatePosition', (position) => {
        players[socket.id] = position;
        io.emit('playersUpdate', players);
    });
});

server.listen(3000, () => {
    console.log('Server is running on port 3000');
});